#!/usr/bin/env bash
#init OS

init_os() {
#Yum
rm -rf /etc/yum.repos.d/*
wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo
#scp -r centos7.repo root@$ip:/etc/yum.repos.d/

#Firewalld & SELinux
#systemctl stop firewalld; systemctl disable firewalld
firewall-cmd --permanent --add-service=http
firewall-cmd --permanent --add-service=https
firewall-cmd --reload
sed -ri '/^SELINUX=/cSELINUX=disabled' /etc/selinux/config; setenforce 0

#ntp
yum -y install chrony
#sed -ri '/3.centos.pool.ntp.org iburst/a\server 192.168.40.140 iburst' /etc/chrony.conf
systemctl start chronyd; systemctl enable chronyd
}
